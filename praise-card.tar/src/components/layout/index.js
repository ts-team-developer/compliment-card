
import LayoutHeader from './LayoutHeader';
import LayoutMain from './LayoutMain';

export { LayoutHeader, LayoutMain };