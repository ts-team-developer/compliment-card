// modal
import AlimPopup from './AlimPopup';
import ConfirmPopup from './ConfirmPopup';

export { AlimPopup, ConfirmPopup };